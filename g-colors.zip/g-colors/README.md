g-colors
========

You can find a list of all Google material design colors here: http://www.google.com/design/spec/style/color.html

Import the _g-colors.scss partial into yout styles.scss manifest file and use any color by using its variable name. 

Ex: Red 500 can be used with the variable $red-500 and Deep Purple A400 with $deep_purple-A400

